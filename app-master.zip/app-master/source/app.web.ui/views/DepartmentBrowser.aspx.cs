using System.Web.UI;

namespace app.web.ui.views
{
    public partial class DepartmentBrowser : Page
    {
    }
}
