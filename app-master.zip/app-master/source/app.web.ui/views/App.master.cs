using System.Web.UI;

namespace app.web.ui.views
{
    public class App : MasterPage
    {
    }
}
